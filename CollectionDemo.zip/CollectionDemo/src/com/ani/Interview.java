package com.ani;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Interview  {
	
	public static void main(String[] args) {
		

		Set list = new HashSet();

/*BTech b = new BTech();
b.time=10;
b.name="Anish";


BCA b1 = new BCA();
b1.time=13;
b1.name="Anis";

MCA b2 = new MCA();
b2.time=11;
b2.name="An";
		
list.add(b1);
list.add(b2);
list.add(b);
*/

		BTech b1 = new BTech();
		b1.time=9;
		b1.name="Anish";
		
		BCA bc1 = new BCA();
		bc1.time=9;
		bc1.name="chf";

		MCA m1 = new MCA();
		m1.time=9;
		m1.name="Anis";

		BTech b2 = new BTech();
		b2.time=10;
		b2.name="Anish";
		
		BCA bc2 = new BCA();
		bc2.time=10;
		bc2.name="Anish";
		
		MCA m2 = new MCA();
		m2.time=10;
		m2.name="Anish";
		
		BTech b3 = new BTech();
		b3.time=11;
		b3.name="Anish";

		BCA bc3 = new BCA();
		bc3.time=11;
		bc3.name="Anis";

		MCA m3 = new MCA();
		m3.time=11;
		m3.name="An";

		list.add(b1);
		list.add(bc1);
		list.add(m1);
		
		list.add(b2);
		list.add(bc2);
		list.add(m2);
		
		list.add(b3);
		list.add(bc3);
		list.add(m3);


		/*list.add(new BTech(9,"Akshay"));
		list.add(new BCA(9,"Sheetal"));
		list.add(new MCA(9,"Neeraj"));
		
		list.add(new BTech(10,"Ashma"));
		list.add(new BCA(10,"Mayur"));
		list.add(new MCA(10,"Abhishek"));
		
		list.add(new BTech(11,"Aniket"));
		list.add(new BCA(11,"Mayuri"));		
		list.add(new MCA(11,"Kamal"));*/
		

		
		System.out.println(list);
		
	}



}


class BTech{
	
	
	public int time;
	public String name;
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	@Override
	public String toString() {
		return "BTech [time=" + time + ", name=" + name + "]";
	}
	public BTech() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BTech(int time, String name) {
		super();
		this.time = time;
		this.name = name;
	}
	
	
	
}
class MCA{
	int time;
	String name;
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "MCA [time=" + time + ", name=" + name + "]";
	}
	public MCA() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MCA(int time, String name) {
		super();
		this.time = time;
		this.name = name;
	}
	
}
class BCA{
	int time;
	String name;
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "BCA [time=" + time + ", name=" + name + "]";
	}
	public BCA() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BCA(int time, String name) {
		super();
		this.time = time;
		this.name = name;
	}
	
	
}
